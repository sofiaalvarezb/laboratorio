from flask import Flask, render_template, request, redirect, session
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "secreto123"

# ---------------- BD ----------------
def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS equipos (
        codigo TEXT PRIMARY KEY,
        nombre TEXT,
        estado TEXT,
        ubicacion TEXT
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS prestamos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        codigo TEXT,
        profesor TEXT,
        fecha TEXT
    )
    """)

    conn.commit()
    conn.close()

    # ---------------- LOGIN ----------------
@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        user = request.form["username"]
        password = request.form["password"]

        conn = get_db()
        usuario = conn.execute("SELECT * FROM usuarios WHERE username=? AND password=?",
                               (user,password)).fetchone()
        conn.close()

        if usuario:
            session["user"] = user
            return redirect("/")

    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# ---------------- REGISTRO USUARIO ----------------
@app.route("/registro", methods=["GET","POST"])
def registro():
    if request.method == "POST":
        user = request.form["username"]
        password = request.form["password"]

        conn = get_db()
        conn.execute("INSERT INTO usuarios (username,password) VALUES (?,?)",(user,password))
        conn.commit()
        conn.close()

        return redirect("/login")

    return render_template("registro.html")

# ---------------- HOME ----------------
@app.route("/")
def index():
    if "user" not in session:
        return redirect("/login")

    conn = get_db()
    equipos = conn.execute("SELECT * FROM equipos").fetchall()
    conn.close()

    return render_template("index.html", equipos=equipos)

# ---------------- AGREGAR EQUIPO ----------------
@app.route("/agregar", methods=["POST"])
def agregar():
    codigo = request.form["codigo"]
    nombre = request.form["nombre"]
    ubicacion = request.form["ubicacion"]

    conn = get_db()
    conn.execute("INSERT INTO equipos VALUES (?,?,?,?)",
                 (codigo,nombre,"disponible",ubicacion))
    conn.commit()
    conn.close()

    return redirect("/")

# ---------------- PRESTAMO ----------------
@app.route("/prestamo", methods=["POST"])
def prestamo():
    codigo = request.form["codigo"]
    profesor = request.form["profesor"]

    conn = get_db()
    conn.execute("UPDATE equipos SET estado='prestado' WHERE codigo=?",(codigo,))
    conn.execute("INSERT INTO prestamos (codigo,profesor,fecha) VALUES (?,?,?)",
                 (codigo,profesor,datetime.now()))
    conn.commit()
    conn.close()

    return redirect("/")

# ---------------- DEVOLUCION ----------------
@app.route("/devolucion", methods=["POST"])
def devolucion():
    codigo = request.form["codigo"]
    

    conn = get_db()
    conn.execute("UPDATE equipos SET estado='disponible' WHERE codigo=?",(codigo,))
    conn.commit()
    conn.close()

    return redirect("/")

# ---------------- MAIN ----------------
if __name__ == "__main__":
    init_db()
    app.run(debug=True)